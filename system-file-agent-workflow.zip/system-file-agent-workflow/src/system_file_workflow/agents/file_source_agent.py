"""File source discovery agent."""

from __future__ import annotations

import fnmatch
import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Iterable

from ..models import FileRecord, FileSource
from ..utils.text import is_probably_ocr_suffix


class FileSourceAgent:
    def load_sources(self, config_path: Path | None = None, scopes: list[Path] | None = None) -> list[FileSource]:
        sources: list[FileSource] = []

        if config_path:
            config_dir = config_path.resolve().parent
            data = json.loads(config_path.read_text(encoding="utf-8"))
            for index, item in enumerate(data.get("file_sources", []), start=1):
                root = Path(item["root_path"])
                if not root.is_absolute():
                    root = config_dir / root
                sources.append(
                    FileSource(
                        source_id=item.get("source_id", f"source_{index}"),
                        name=item.get("name", f"Source {index}"),
                        root_path=root,
                        enabled=item.get("enabled", True),
                        include_patterns=item.get("include_patterns", ["*"]),
                        exclude_patterns=item.get(
                            "exclude_patterns",
                            [".git/", "__pycache__/", "node_modules/", ".venv/", "venv/"],
                        ),
                        enable_ocr=item.get("enable_ocr", False),
                        description=item.get("description", ""),
                    )
                )

        for index, scope in enumerate(scopes or [], start=1):
            sources.append(
                FileSource(
                    source_id=f"scope_{index}",
                    name=f"CLI scope {index}",
                    root_path=scope,
                    include_patterns=["*"],
                    enable_ocr=True,
                )
            )

        return [source for source in sources if source.enabled]

    def discover(self, sources: Iterable[FileSource]) -> list[FileRecord]:
        records: list[FileRecord] = []
        for source in sources:
            if not source.root_path.exists():
                continue
            for path in sorted(source.root_path.rglob("*")):
                if not path.is_file():
                    continue
                if self._excluded(path, source.root_path, source.exclude_patterns):
                    continue
                if not self._included(path, source.include_patterns):
                    continue
                records.append(self._record_for(source, path))
        return records

    def _included(self, path: Path, include_patterns: list[str]) -> bool:
        return any(fnmatch.fnmatch(path.name, pattern) for pattern in include_patterns)

    def _excluded(self, path: Path, root: Path, exclude_patterns: list[str]) -> bool:
        rel = path.relative_to(root)
        rel_text = rel.as_posix()
        for pattern in exclude_patterns:
            if pattern.endswith("/"):
                folder = pattern.rstrip("/")
                if folder in rel.parts:
                    return True
            elif fnmatch.fnmatch(path.name, pattern) or fnmatch.fnmatch(rel_text, pattern):
                return True
        return False

    def _record_for(self, source: FileSource, path: Path) -> FileRecord:
        stat = path.stat()
        return FileRecord(
            source_id=source.source_id,
            path=path,
            suffix=path.suffix.lower(),
            size=stat.st_size,
            modified_at=datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
            sha256=self._sha256(path),
            needs_ocr=is_probably_ocr_suffix(path),
        )

    def _sha256(self, path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()
