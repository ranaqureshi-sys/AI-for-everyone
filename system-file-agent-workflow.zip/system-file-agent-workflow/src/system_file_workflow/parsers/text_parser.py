"""Parser for plain text files."""

from __future__ import annotations

from pathlib import Path

from ..models import DocumentChunk, Location, SourceKind
from ..utils.text import TEXT_SUFFIXES, context_for_lines, line_start_offsets, read_text_with_fallback
from .base import BaseParser


class TextParser(BaseParser):
    supported_suffixes = TEXT_SUFFIXES

    def parse(self, path: Path) -> list[DocumentChunk]:
        content, encoding = read_text_with_fallback(path)
        raw_lines = content.splitlines()
        offsets = line_start_offsets(content)
        chunks: list[DocumentChunk] = []

        for index, line in enumerate(raw_lines):
            before, after = context_for_lines(raw_lines, index)
            start = offsets[index] if index < len(offsets) else 0
            chunks.append(
                DocumentChunk(
                    file_path=path,
                    text=line,
                    location=Location(
                        label=f"line {index + 1}",
                        line=index + 1,
                        start=start,
                        end=start + len(line),
                    ),
                    source_kind=SourceKind.NATIVE_TEXT,
                    confidence=1.0,
                    context_before=before,
                    context_after=after,
                    metadata={"encoding": encoding},
                )
            )

        return chunks
