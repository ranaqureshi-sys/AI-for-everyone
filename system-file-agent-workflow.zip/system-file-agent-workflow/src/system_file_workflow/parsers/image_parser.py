"""Image/OCR placeholder parser."""

from __future__ import annotations

from pathlib import Path

from ..models import DocumentChunk, Location, SourceKind
from ..utils.text import IMAGE_SUFFIXES
from .base import BaseParser


class ImageParser(BaseParser):
    supported_suffixes = IMAGE_SUFFIXES

    def parse(self, path: Path) -> list[DocumentChunk]:
        return [
            DocumentChunk(
                file_path=path,
                text="",
                location=Location(label="image ocr pending"),
                source_kind=SourceKind.OCR_TEXT,
                confidence=0.0,
                evidence_path=path,
                metadata={
                    "parser": "image-placeholder",
                    "message": "Image needs OCR provider. Keep it in high-risk review scope.",
                },
            )
        ]
