"""Basic XLSX text extractor."""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import BadZipFile, ZipFile

from ..models import DocumentChunk, Location, SourceKind
from .base import BaseParser


NS_MAIN = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
REL_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
PKG_REL_NS = "{http://schemas.openxmlformats.org/package/2006/relationships}"


class XlsxParser(BaseParser):
    supported_suffixes = {".xlsx"}

    def parse(self, path: Path) -> list[DocumentChunk]:
        try:
            with ZipFile(path) as archive:
                shared_strings = self._read_shared_strings(archive)
                sheet_names = self._read_sheet_names(archive)
                sheet_paths = sorted(
                    name for name in archive.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml", name)
                )
                chunks: list[DocumentChunk] = []
                for sheet_index, sheet_path in enumerate(sheet_paths, start=1):
                    sheet_name = sheet_names.get(sheet_index, f"Sheet{sheet_index}")
                    chunks.extend(self._read_sheet(archive, sheet_path, sheet_name, shared_strings, path))
                return chunks
        except (KeyError, BadZipFile, ET.ParseError):
            return []

    def _read_shared_strings(self, archive: ZipFile) -> list[str]:
        try:
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
        except KeyError:
            return []

        values = []
        for item in root.iter(f"{NS_MAIN}si"):
            text = "".join(node.text or "" for node in item.iter(f"{NS_MAIN}t"))
            values.append(text)
        return values

    def _read_sheet_names(self, archive: ZipFile) -> dict[int, str]:
        try:
            root = ET.fromstring(archive.read("xl/workbook.xml"))
        except KeyError:
            return {}

        names: dict[int, str] = {}
        for index, sheet in enumerate(root.iter(f"{NS_MAIN}sheet"), start=1):
            names[index] = sheet.attrib.get("name", f"Sheet{index}")
        return names

    def _read_sheet(
        self,
        archive: ZipFile,
        sheet_path: str,
        sheet_name: str,
        shared_strings: list[str],
        file_path: Path,
    ) -> list[DocumentChunk]:
        root = ET.fromstring(archive.read(sheet_path))
        chunks: list[DocumentChunk] = []
        for cell in root.iter(f"{NS_MAIN}c"):
            ref = cell.attrib.get("r", "")
            value_node = cell.find(f"{NS_MAIN}v")
            inline_text = "".join(node.text or "" for node in cell.iter(f"{NS_MAIN}t"))
            value = ""
            if cell.attrib.get("t") == "s" and value_node is not None:
                idx = int(value_node.text or "0")
                if idx < len(shared_strings):
                    value = shared_strings[idx]
            elif inline_text:
                value = inline_text
            elif value_node is not None:
                value = value_node.text or ""

            if not value:
                continue

            row, col = self._split_cell_ref(ref)
            chunks.append(
                DocumentChunk(
                    file_path=file_path,
                    text=value,
                    location=Location(
                        label=f"{sheet_name}!{ref or '?'}",
                        sheet=sheet_name,
                        row=row,
                        col=col,
                    ),
                    source_kind=SourceKind.NATIVE_TEXT,
                    confidence=1.0,
                    metadata={"parser": "xlsx-basic", "cell": ref},
                )
            )
        return chunks

    def _split_cell_ref(self, ref: str) -> tuple[int | None, int | None]:
        match = re.match(r"([A-Z]+)(\d+)", ref)
        if not match:
            return None, None
        letters, row = match.groups()
        col = 0
        for char in letters:
            col = col * 26 + (ord(char) - ord("A") + 1)
        return int(row), col
