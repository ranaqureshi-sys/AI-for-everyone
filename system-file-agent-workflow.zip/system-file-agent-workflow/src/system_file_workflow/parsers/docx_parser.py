"""Basic DOCX text extractor."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import BadZipFile, ZipFile

from ..models import DocumentChunk, Location, SourceKind
from .base import BaseParser


W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


class DocxParser(BaseParser):
    supported_suffixes = {".docx"}

    def parse(self, path: Path) -> list[DocumentChunk]:
        try:
            with ZipFile(path) as archive:
                document_xml = archive.read("word/document.xml")
        except (KeyError, BadZipFile):
            return []

        root = ET.fromstring(document_xml)
        paragraphs: list[str] = []
        for paragraph in root.iter(f"{W_NS}p"):
            parts = [node.text or "" for node in paragraph.iter(f"{W_NS}t")]
            text = "".join(parts).strip()
            if text:
                paragraphs.append(text)

        chunks: list[DocumentChunk] = []
        for index, text in enumerate(paragraphs):
            chunks.append(
                DocumentChunk(
                    file_path=path,
                    text=text,
                    location=Location(
                        label=f"paragraph {index + 1}",
                        paragraph=index + 1,
                    ),
                    source_kind=SourceKind.NATIVE_TEXT,
                    confidence=1.0,
                    context_before=paragraphs[max(0, index - 2) : index],
                    context_after=paragraphs[index + 1 : min(len(paragraphs), index + 3)],
                    metadata={"parser": "docx-basic"},
                )
            )
        return chunks
