"""Risk classification agent for candidates."""

from __future__ import annotations

import uuid

from ..models import CandidateStatus, ChangeCandidate, RiskLevel, SearchHit, SourceKind
from .search_agent import AMBIGUOUS_GROUPS


class RiskAgent:
    def build_candidates(self, hits: list[SearchHit], task_id: str) -> list[ChangeCandidate]:
        candidates: list[ChangeCandidate] = []
        for index, hit in enumerate(hits, start=1):
            risk_level, reasons = self.classify(hit)
            candidates.append(
                ChangeCandidate(
                    candidate_id=f"C{index:04d}_{uuid.uuid4().hex[:6]}",
                    task_id=task_id,
                    file_path=hit.file_path,
                    file_type=hit.file_path.suffix.lower() or "unknown",
                    location=hit.location,
                    original_text=hit.match_text,
                    replacement_text=hit.replacement_text,
                    source_kind=hit.source_kind,
                    confidence=hit.confidence,
                    risk_level=risk_level,
                    risk_reasons=reasons,
                    context_before=hit.context_before,
                    context_after=hit.context_after,
                    absolute_start=hit.absolute_start,
                    absolute_end=hit.absolute_end,
                    evidence_path=hit.evidence_path,
                    status=CandidateStatus.PENDING,
                )
            )
        return candidates

    def classify(self, hit: SearchHit) -> tuple[RiskLevel, list[str]]:
        reasons: list[str] = []
        risk = RiskLevel.LOW

        if hit.source_kind == SourceKind.OCR_TEXT:
            risk = RiskLevel.HIGH
            reasons.append("OCR/扫描/图片来源，必须人工核对原图")

        if hit.confidence < 0.8:
            risk = RiskLevel.HIGH
            reasons.append(f"识别置信度较低: {hit.confidence:.2f}")
        elif hit.confidence < 0.95:
            risk = max_risk(risk, RiskLevel.MEDIUM)
            reasons.append(f"识别置信度需要关注: {hit.confidence:.2f}")

        ambiguous_reasons = self._ambiguous_reasons(hit.match_text)
        if ambiguous_reasons:
            risk = RiskLevel.HIGH
            reasons.extend(ambiguous_reasons)

        if hit.metadata.get("pattern_label") == "ambiguous_variant":
            risk = RiskLevel.HIGH
            reasons.append("通过易混字符变体命中，可能存在手写/OCR误识别")

        if not reasons:
            reasons.append("普通文本精确命中")

        return risk, reasons

    def _ambiguous_reasons(self, text: str) -> list[str]:
        reasons: list[str] = []
        for group in AMBIGUOUS_GROUPS:
            found = [token for token in group if token in text]
            if len(found) >= 1 and any(token.isalnum() for token in found):
                if any(token in text for token in ("L", "1", "I", "l", "O", "0", "B", "8", "13")):
                    reasons.append("包含易混字符: " + "/".join(group))
        return reasons


def max_risk(left: RiskLevel, right: RiskLevel) -> RiskLevel:
    order = {RiskLevel.LOW: 1, RiskLevel.MEDIUM: 2, RiskLevel.HIGH: 3}
    return left if order[left] >= order[right] else right
