# 体系文件智能检索与人工确认式批量修改工作流

这是一个参考原始 `AI-for-everyone` 项目重新整理的新版本原型。它不只是“查找替换”，而是把体系文件维护拆成一条完整工作流：

1. 注册多个文件源。
2. 扫描和索引分散文件。
3. 按文件类型解析为统一文本块。
4. 检索目标句子或关键词。
5. 标出每条命中的文件、位置和上下文。
6. 对 OCR、手写体和易混字符做风险分级。
7. 汇总成逐条候选修改清单。
8. 人工逐条确认、跳过或编辑。
9. 执行已确认修改，生成备份、审计报告和回滚材料。

## 项目结构

```text
system-file-agent-workflow/
├── src/system_file_workflow/
│   ├── agents/              # Agent 编排层
│   ├── parsers/             # TXT/MD/DOCX/XLSX/PDF/图片解析器
│   ├── utils/               # 备份、序列化、文本工具
│   ├── cli.py               # 命令行入口
│   └── workflow.py          # 端到端工作流编排
├── skills/                  # 面向业务和开发的 Agent skill 说明
├── docs/                    # 工作流、架构、验收标准
├── examples/                # 示例文件源和样例体系文件
└── tests/                   # 基础测试
```

## 快速运行

在项目目录下执行：

```bash
python -m system_file_workflow run "质量管理体系" "质量管控体系" --config examples/file_sources.json --dry-run
```

如果没有安装成包，可以临时指定源码路径：

```bash
$env:PYTHONPATH="src"
python -m system_file_workflow run "质量管理体系" "质量管控体系" --config examples/file_sources.json --dry-run
```

进入逐条确认并执行普通文本替换：

```bash
$env:PYTHONPATH="src"
python -m system_file_workflow run "质量管理体系" "质量管控体系" --config examples/file_sources.json
```

输出候选清单 JSON：

```bash
$env:PYTHONPATH="src"
python -m system_file_workflow scan "质量管理体系" "质量管控体系" --config examples/file_sources.json --output out/candidates.json
```

## 当前能力

- 支持多个文件源统一扫描。
- 支持 TXT、MD、CSV、JSON、YAML 等文本文件解析。
- 支持 DOCX 基础文本抽取。
- 支持 XLSX 基础单元格文本抽取。
- 支持 PDF/图片作为 OCR 待接入对象进入风险流程。
- 支持精确匹配、正则匹配、易混字符变体匹配。
- 支持逐条人工确认。
- 支持低风险项自动确认开关。
- 支持普通文本文件安全替换。
- 支持 DOCX/XLSX 的基础 XML 替换尝试。
- 支持修改前备份、执行报告和失败记录。

## OCR 和手写体策略

扫描件、图片和手写体不直接自动修改。系统会把它们作为高风险候选项处理，重点识别：

- `L` / `1` / `I` / `l`
- `O` / `0`
- `B` / `8` / `13`
- OCR 低置信度文本
- 扫描件或图片中无法稳定定位的内容

后续接入真实 OCR 服务时，只需要替换 `ImageParser` 或新增 OCR provider，让它输出标准 `DocumentChunk` 即可。

## 推荐阅读

- [完整工作流](docs/workflow.md)
- [技术架构](docs/architecture.md)
- [验收标准](docs/acceptance.md)
- [Agent Skills](skills/README.md)

## 与原始项目的区别

原始项目主要是 CLI 文本批量替换工具；这个新版本把它升级为“候选项驱动”的受控工作流：

- 先建立文件源和索引，再检索。
- 先解析为标准文本块，再匹配。
- 先生成候选项，再逐条确认。
- OCR 和手写项必须风险标记。
- 执行前校验，执行后留痕。
