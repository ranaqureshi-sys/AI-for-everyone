"""Core data models for the document replacement workflow."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Optional


class SourceKind(str, Enum):
    NATIVE_TEXT = "native_text"
    OCR_TEXT = "ocr_text"
    UNSUPPORTED = "unsupported"


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class CandidateStatus(str, Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    SKIPPED = "skipped"
    EDITED = "edited"
    EXECUTED = "executed"
    FAILED = "failed"
    MANUAL_REQUIRED = "manual_required"


@dataclass
class FileSource:
    source_id: str
    name: str
    root_path: Path
    enabled: bool = True
    include_patterns: list[str] = field(default_factory=lambda: ["*"])
    exclude_patterns: list[str] = field(
        default_factory=lambda: [".git/", "__pycache__/", "node_modules/", ".venv/", "venv/"]
    )
    enable_ocr: bool = False
    description: str = ""


@dataclass
class FileRecord:
    source_id: str
    path: Path
    suffix: str
    size: int
    modified_at: str
    sha256: str
    needs_ocr: bool = False


@dataclass
class Location:
    label: str
    line: Optional[int] = None
    column: Optional[int] = None
    page: Optional[int] = None
    sheet: Optional[str] = None
    row: Optional[int] = None
    col: Optional[int] = None
    paragraph: Optional[int] = None
    start: int = 0
    end: int = 0


@dataclass
class DocumentChunk:
    file_path: Path
    text: str
    location: Location
    source_kind: SourceKind = SourceKind.NATIVE_TEXT
    confidence: float = 1.0
    context_before: list[str] = field(default_factory=list)
    context_after: list[str] = field(default_factory=list)
    evidence_path: Optional[Path] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SearchHit:
    file_path: Path
    original_text: str
    replacement_text: str
    location: Location
    source_kind: SourceKind
    confidence: float
    context_before: list[str]
    context_after: list[str]
    match_text: str
    absolute_start: int = 0
    absolute_end: int = 0
    evidence_path: Optional[Path] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ChangeCandidate:
    candidate_id: str
    task_id: str
    file_path: Path
    file_type: str
    location: Location
    original_text: str
    replacement_text: str
    source_kind: SourceKind
    confidence: float
    risk_level: RiskLevel
    risk_reasons: list[str]
    context_before: list[str]
    context_after: list[str]
    absolute_start: int = 0
    absolute_end: int = 0
    evidence_path: Optional[Path] = None
    status: CandidateStatus = CandidateStatus.PENDING
    reviewer_note: str = ""

    @property
    def location_label(self) -> str:
        return self.location.label


@dataclass
class ChangeDecision:
    candidate_id: str
    confirmed: bool
    replacement_text: Optional[str] = None
    note: str = ""


@dataclass
class ChangeRecord:
    candidate_id: str
    file_path: Path
    backup_path: Optional[Path]
    original_text: str
    replacement_text: str
    location_label: str
    success: bool
    message: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))


@dataclass
class WorkflowResult:
    task_id: str
    total_files: int
    total_chunks: int
    total_candidates: int
    confirmed: int
    skipped: int
    executed: int
    failed: int
    report_path: Optional[Path] = None


def to_jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {key: to_jsonable(item) for key, item in asdict(value).items()}
    if isinstance(value, list):
        return [to_jsonable(item) for item in value]
    if isinstance(value, tuple):
        return [to_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(key): to_jsonable(item) for key, item in value.items()}
    return value
