# 技术架构

## 架构原则

1. 机器负责找全、定位、提示风险。
2. 人负责最终确认。
3. 执行前必须备份。
4. 执行后必须留痕。
5. OCR 和手写体不直接自动改。

## 模块分层

```text
CLI/API
  ↓
SystemFileWorkflow
  ↓
FileSourceAgent
  ↓
ParseAgent
  ↓
SearchAgent
  ↓
RiskAgent
  ↓
ReviewAgent
  ↓
ExecuteAgent
  ↓
AuditAgent
```

## 数据模型

### FileSource

描述一个文件来源，例如共享盘、归档目录或上传目录。

### FileRecord

描述被扫描到的真实文件，包括路径、大小、修改时间、哈希和是否需要 OCR。

### DocumentChunk

所有文件解析后的统一文本块。后续检索逻辑只处理文本块，不直接关心原始文件类型。

### SearchHit

检索命中的原始结果，包括位置、上下文、命中文本和置信度。

### ChangeCandidate

待人工确认的最小审核单元。系统最终应该围绕候选项做审核、执行和审计。

### ChangeRecord

执行结果记录，包含备份位置、成功状态和失败原因。

## OCR 接入点

当前代码中的 `ImageParser` 和 `PdfParser` 是占位适配器。正式接入时可以扩展为：

```text
图片/PDF
  ↓
图像预处理
  ↓
OCR 服务
  ↓
识别文本 + 置信度 + 坐标 + 裁切图
  ↓
DocumentChunk
```

只要 OCR provider 能输出 `DocumentChunk`，后面的检索、风险、审核和报告都可以复用。

## 后续 Web 化

当前项目先以 CLI 跑通流程。Web 化时建议保留这些 Agent，把 `ReviewAgent` 的命令行交互替换为页面审核：

- 任务创建页
- 文件源管理页
- 候选项列表页
- 候选项详情页
- 原图/OCR 对照区
- 执行结果页
- 报告下载页
