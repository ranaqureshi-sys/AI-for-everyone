"""Minimal Office Open XML replacement utilities.

This is intentionally conservative. It is good enough for POC documents where
the matched phrase is stored as contiguous XML text, but production usage should
replace this with a richer DOCX/XLSX writer.
"""

from __future__ import annotations

import html
import shutil
import tempfile
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


def replace_in_office_zip(path: Path, entry_prefixes: tuple[str, ...], replacements: list[tuple[str, str]]) -> int:
    replaced_count = 0
    escaped_replacements = [(html.escape(old), html.escape(new)) for old, new in replacements]

    with tempfile.NamedTemporaryFile(delete=False, suffix=path.suffix) as tmp:
        temp_path = Path(tmp.name)

    try:
        with ZipFile(path, "r") as source, ZipFile(temp_path, "w", ZIP_DEFLATED) as target:
            for info in source.infolist():
                data = source.read(info.filename)
                if info.filename.startswith(entry_prefixes) and info.filename.endswith(".xml"):
                    text = data.decode("utf-8")
                    for old, new in escaped_replacements:
                        if old in text:
                            occurrences = text.count(old)
                            text = text.replace(old, new)
                            replaced_count += occurrences
                    target.writestr(info, text.encode("utf-8"))
                else:
                    target.writestr(info, data)
        shutil.move(str(temp_path), path)
    finally:
        if temp_path.exists():
            temp_path.unlink()

    return replaced_count
