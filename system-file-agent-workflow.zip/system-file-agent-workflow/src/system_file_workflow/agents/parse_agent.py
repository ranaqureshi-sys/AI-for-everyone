"""Document parsing agent."""

from __future__ import annotations

from ..models import DocumentChunk, FileRecord
from ..parsers import DocxParser, ImageParser, PdfParser, TextParser, XlsxParser
from ..parsers.base import BaseParser


class ParseAgent:
    def __init__(self, parsers: list[BaseParser] | None = None):
        self.parsers = parsers or [TextParser(), DocxParser(), XlsxParser(), PdfParser(), ImageParser()]

    def parse_records(self, records: list[FileRecord]) -> list[DocumentChunk]:
        chunks: list[DocumentChunk] = []
        for record in records:
            parser = self._parser_for(record)
            if parser is None:
                continue
            chunks.extend(parser.parse(record.path))
        return chunks

    def _parser_for(self, record: FileRecord) -> BaseParser | None:
        for parser in self.parsers:
            if parser.supports(record.path):
                return parser
        return None
