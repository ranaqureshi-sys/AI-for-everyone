"""End-to-end workflow orchestration."""

from __future__ import annotations

import uuid
from pathlib import Path

from .agents import AuditAgent, ExecuteAgent, FileSourceAgent, MatchMode, ParseAgent, ReviewAgent, RiskAgent, SearchAgent
from .models import ChangeCandidate, WorkflowResult
from .utils.backup import BackupManager


class SystemFileWorkflow:
    def __init__(self, output_dir: Path | None = None, backup_dir: Path | None = None):
        self.output_dir = output_dir or Path.cwd() / "out"
        self.file_source_agent = FileSourceAgent()
        self.parse_agent = ParseAgent()
        self.search_agent = SearchAgent()
        self.risk_agent = RiskAgent()
        self.review_agent = ReviewAgent()
        self.audit_agent = AuditAgent(self.output_dir)
        self.execute_agent = ExecuteAgent(BackupManager(backup_dir or self.output_dir / "backups"))

    def scan(
        self,
        target: str,
        replacement: str,
        config_path: Path | None = None,
        scopes: list[Path] | None = None,
        mode: MatchMode = MatchMode.EXACT,
        case_sensitive: bool = False,
    ) -> tuple[str, list[ChangeCandidate], int, int]:
        task_id = uuid.uuid4().hex[:12]
        sources = self.file_source_agent.load_sources(config_path=config_path, scopes=scopes)
        records = self.file_source_agent.discover(sources)
        chunks = self.parse_agent.parse_records(records)
        hits = self.search_agent.search(
            chunks=chunks,
            target=target,
            replacement=replacement,
            mode=mode,
            case_sensitive=case_sensitive,
        )
        candidates = self.risk_agent.build_candidates(hits, task_id=task_id)
        return task_id, candidates, len(records), len(chunks)

    def run(
        self,
        target: str,
        replacement: str,
        config_path: Path | None = None,
        scopes: list[Path] | None = None,
        mode: MatchMode = MatchMode.EXACT,
        case_sensitive: bool = False,
        dry_run: bool = False,
        auto_confirm_low_risk: bool = False,
    ) -> WorkflowResult:
        task_id, candidates, total_files, total_chunks = self.scan(
            target=target,
            replacement=replacement,
            config_path=config_path,
            scopes=scopes,
            mode=mode,
            case_sensitive=case_sensitive,
        )

        if dry_run:
            report_path = self.audit_agent.write_report(task_id, candidates, [])
            return self.audit_agent.summarize(task_id, total_files, total_chunks, candidates, [], report_path)

        decisions = self.review_agent.review(
            candidates,
            interactive=True,
            auto_confirm_low_risk=auto_confirm_low_risk,
        )
        records = self.execute_agent.execute(candidates, decisions)
        report_path = self.audit_agent.write_report(task_id, candidates, records)
        return self.audit_agent.summarize(task_id, total_files, total_chunks, candidates, records, report_path)
