"""PDF placeholder parser.

Text PDFs and scanned PDFs usually need a dedicated library or OCR service.
This parser keeps them visible in the workflow instead of silently skipping them.
"""

from __future__ import annotations

from pathlib import Path

from ..models import DocumentChunk, Location, SourceKind
from .base import BaseParser


class PdfParser(BaseParser):
    supported_suffixes = {".pdf"}

    def parse(self, path: Path) -> list[DocumentChunk]:
        return [
            DocumentChunk(
                file_path=path,
                text="",
                location=Location(label="pdf document"),
                source_kind=SourceKind.OCR_TEXT,
                confidence=0.0,
                metadata={
                    "parser": "pdf-placeholder",
                    "message": "PDF needs text extraction or OCR provider before replacement.",
                },
            )
        ]
