"""Search agent that creates raw hits from parsed document chunks."""

from __future__ import annotations

import itertools
import re
from enum import Enum

from ..models import DocumentChunk, Location, SearchHit


class MatchMode(str, Enum):
    EXACT = "exact"
    REGEX = "regex"
    AMBIGUOUS = "ambiguous"


AMBIGUOUS_GROUPS = [
    ("L", "1", "I", "l"),
    ("O", "0"),
    ("B", "8", "13"),
]


class SearchAgent:
    def search(
        self,
        chunks: list[DocumentChunk],
        target: str,
        replacement: str,
        mode: MatchMode = MatchMode.EXACT,
        case_sensitive: bool = False,
    ) -> list[SearchHit]:
        hits: list[SearchHit] = []
        for chunk in chunks:
            if not chunk.text:
                continue
            patterns = self._patterns(target, mode)
            for pattern, pattern_label in patterns:
                flags = 0 if case_sensitive else re.IGNORECASE
                for match in re.finditer(pattern, chunk.text, flags):
                    absolute_start = chunk.location.start + match.start()
                    absolute_end = chunk.location.start + match.end()
                    location = Location(
                        label=self._location_label(chunk.location, match.start() + 1),
                        line=chunk.location.line,
                        column=match.start() + 1,
                        page=chunk.location.page,
                        sheet=chunk.location.sheet,
                        row=chunk.location.row,
                        col=chunk.location.col,
                        paragraph=chunk.location.paragraph,
                        start=absolute_start,
                        end=absolute_end,
                    )
                    hits.append(
                        SearchHit(
                            file_path=chunk.file_path,
                            original_text=target,
                            replacement_text=replacement,
                            location=location,
                            source_kind=chunk.source_kind,
                            confidence=chunk.confidence,
                            context_before=chunk.context_before,
                            context_after=chunk.context_after,
                            match_text=match.group(0),
                            absolute_start=absolute_start,
                            absolute_end=absolute_end,
                            evidence_path=chunk.evidence_path,
                            metadata={**chunk.metadata, "pattern_label": pattern_label},
                        )
                    )
        return hits

    def _location_label(self, location: Location, column: int) -> str:
        if location.line is not None:
            return f"line {location.line}, col {column}"
        if location.paragraph is not None:
            return f"paragraph {location.paragraph}, char {column}"
        if location.sheet and location.row and location.col:
            return location.label
        return location.label

    def _patterns(self, target: str, mode: MatchMode) -> list[tuple[str, str]]:
        if mode == MatchMode.REGEX:
            return [(target, "regex")]

        patterns = [(re.escape(target), "exact")]
        if mode == MatchMode.AMBIGUOUS:
            variants = self._ambiguous_variants(target)
            patterns.extend((re.escape(variant), "ambiguous_variant") for variant in variants if variant != target)
        return patterns

    def _ambiguous_variants(self, target: str, max_variants: int = 64) -> set[str]:
        choices: list[list[str]] = []
        index = 0
        while index < len(target):
            matched = False
            for group in AMBIGUOUS_GROUPS:
                for token in sorted(group, key=len, reverse=True):
                    if target[index : index + len(token)] == token:
                        choices.append(list(group))
                        index += len(token)
                        matched = True
                        break
                if matched:
                    break
            if not matched:
                choices.append([target[index]])
                index += 1

        variants = set()
        for combo in itertools.islice(itertools.product(*choices), max_variants):
            variants.add("".join(combo))
        return variants
