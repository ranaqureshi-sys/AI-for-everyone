import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from system_file_workflow.agents import ExecuteAgent, FileSourceAgent, MatchMode, ParseAgent, RiskAgent, SearchAgent
from system_file_workflow.models import ChangeDecision, RiskLevel
from system_file_workflow.utils.backup import BackupManager


class WorkflowTests(unittest.TestCase):
    def test_text_workflow_discovers_searches_and_executes(self):
        old = "\u8d28\u91cf\u7ba1\u7406\u4f53\u7cfb"
        new = "\u8d28\u91cf\u7ba1\u63a7\u4f53\u7cfb"

        with TemporaryDirectory() as td:
            root = Path(td)
            source = root / "docs"
            source.mkdir()
            file_path = source / "manual.md"
            file_path.write_text(
                f"one\n{old} needs update.\nsecond {old}.\n",
                encoding="utf-8",
                newline="",
            )

            config = root / "sources.json"
            config.write_text(
                '{"file_sources":[{"source_id":"docs","name":"docs","root_path":"'
                + source.as_posix()
                + '","include_patterns":["*.md"]}]}',
                encoding="utf-8",
            )

            source_agent = FileSourceAgent()
            sources = source_agent.load_sources(config_path=config)
            records = source_agent.discover(sources)
            self.assertEqual(len(records), 1)

            chunks = ParseAgent().parse_records(records)
            hits = SearchAgent().search(chunks, old, new, mode=MatchMode.EXACT)
            candidates = RiskAgent().build_candidates(hits, task_id="task")
            self.assertEqual(len(candidates), 2)
            self.assertTrue(all(candidate.risk_level == RiskLevel.LOW for candidate in candidates))

            decisions = [ChangeDecision(candidate.candidate_id, True) for candidate in candidates]
            executor = ExecuteAgent(BackupManager(root / "backups"))
            change_records = executor.execute(candidates, decisions)

            content = file_path.read_text(encoding="utf-8-sig")
            self.assertTrue(all(record.success for record in change_records))
            self.assertNotIn(old, content)
            self.assertEqual(content.count(new), 2)

    def test_ambiguous_match_is_high_risk(self):
        with TemporaryDirectory() as td:
            file_path = Path(td) / "risk.txt"
            file_path.write_text("表单编号 8-13 可能原本是 B-13。\n", encoding="utf-8")

            record = type("Record", (), {"path": file_path, "suffix": ".txt"})
            chunks = ParseAgent().parse_records([record])
            hits = SearchAgent().search(chunks, "B-13", "B-14", mode=MatchMode.AMBIGUOUS)
            candidates = RiskAgent().build_candidates(hits, task_id="risk")

            self.assertTrue(candidates)
            self.assertTrue(any(candidate.risk_level == RiskLevel.HIGH for candidate in candidates))
            self.assertTrue(any("B/8/13" in " ".join(candidate.risk_reasons) for candidate in candidates))


if __name__ == "__main__":
    unittest.main()
