"""Text helpers shared by parsers and agents."""

from __future__ import annotations

import re
from pathlib import Path


TEXT_SUFFIXES = {
    ".txt",
    ".md",
    ".csv",
    ".json",
    ".yaml",
    ".yml",
    ".ini",
    ".cfg",
    ".log",
}

OFFICE_SUFFIXES = {".docx", ".xlsx"}
PDF_SUFFIXES = {".pdf"}
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def read_text_with_fallback(path: Path) -> tuple[str, str]:
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "gb18030", "gbk", "cp936"):
        try:
            return raw.decode(encoding), encoding
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", errors="replace"), "latin-1"


def line_start_offsets(text: str) -> list[int]:
    offsets = []
    cursor = 0
    for line in text.splitlines(keepends=True):
        offsets.append(cursor)
        cursor += len(line)
    if not offsets:
        offsets.append(0)
    return offsets


def context_for_lines(lines: list[str], index: int, radius: int = 2) -> tuple[list[str], list[str]]:
    before = lines[max(0, index - radius) : index]
    after = lines[index + 1 : min(len(lines), index + radius + 1)]
    return before, after


def compact_preview(text: str, width: int = 120) -> str:
    normalized = re.sub(r"\s+", " ", text).strip()
    if len(normalized) <= width:
        return normalized
    return normalized[: width - 3] + "..."


def is_probably_ocr_suffix(path: Path) -> bool:
    return path.suffix.lower() in PDF_SUFFIXES | IMAGE_SUFFIXES


def escape_markdown_cell(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", "<br>")
