"""Parser interfaces."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from ..models import DocumentChunk


class BaseParser(ABC):
    supported_suffixes: set[str] = set()

    def supports(self, path: Path) -> bool:
        return path.suffix.lower() in self.supported_suffixes

    @abstractmethod
    def parse(self, path: Path) -> list[DocumentChunk]:
        raise NotImplementedError
