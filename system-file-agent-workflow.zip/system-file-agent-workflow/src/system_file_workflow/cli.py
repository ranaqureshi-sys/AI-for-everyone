"""Command line interface."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .agents.search_agent import MatchMode
from .agents.audit_agent import AuditAgent
from .models import to_jsonable
from .workflow import SystemFileWorkflow


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="system-file-workflow",
        description="体系文件智能检索与人工确认式批量修改工作流",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = subparsers.add_parser("scan", help="只生成候选项，不执行修改")
    add_common_args(scan_parser)
    scan_parser.add_argument("--output", type=Path, default=Path("out/candidates.json"), help="候选项输出路径")

    run_parser = subparsers.add_parser("run", help="运行完整工作流")
    add_common_args(run_parser)
    run_parser.add_argument("--dry-run", action="store_true", help="只生成报告，不进入确认和执行")
    run_parser.add_argument("--auto-confirm-low-risk", action="store_true", help="低风险普通文本项自动确认")

    args = parser.parse_args(argv)

    workflow = SystemFileWorkflow(output_dir=args.output_dir, backup_dir=args.backup_dir)
    mode = MatchMode(args.mode)

    if args.command == "scan":
        task_id, candidates, total_files, total_chunks = workflow.scan(
            target=args.target,
            replacement=args.replacement,
            config_path=args.config,
            scopes=args.scope,
            mode=mode,
            case_sensitive=args.case_sensitive,
        )
        audit = AuditAgent(args.output_dir)
        audit.write_candidates(candidates, args.output)
        print_summary(task_id, total_files, total_chunks, len(candidates), args.output)
        return

    if args.command == "run":
        result = workflow.run(
            target=args.target,
            replacement=args.replacement,
            config_path=args.config,
            scopes=args.scope,
            mode=mode,
            case_sensitive=args.case_sensitive,
            dry_run=args.dry_run,
            auto_confirm_low_risk=args.auto_confirm_low_risk,
        )
        print(json.dumps(to_jsonable(result), ensure_ascii=False, indent=2))


def add_common_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("target", help="待查找内容")
    parser.add_argument("replacement", help="建议替换内容")
    parser.add_argument("--config", type=Path, help="文件源 JSON 配置")
    parser.add_argument("--scope", type=Path, action="append", default=[], help="额外搜索目录，可重复")
    parser.add_argument(
        "--mode",
        choices=[item.value for item in MatchMode],
        default=MatchMode.EXACT.value,
        help="匹配模式",
    )
    parser.add_argument("--case-sensitive", action="store_true", help="区分大小写")
    parser.add_argument("--output-dir", type=Path, default=Path("out"), help="报告输出目录")
    parser.add_argument("--backup-dir", type=Path, help="备份目录")


def print_summary(task_id: str, total_files: int, total_chunks: int, total_candidates: int, output: Path) -> None:
    print(f"任务编号: {task_id}")
    print(f"扫描文件: {total_files}")
    print(f"文本块: {total_chunks}")
    print(f"候选项: {total_candidates}")
    print(f"候选清单: {output}")
