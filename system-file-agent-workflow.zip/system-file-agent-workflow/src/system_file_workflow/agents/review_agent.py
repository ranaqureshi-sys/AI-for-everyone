"""Human review agent."""

from __future__ import annotations

from ..models import CandidateStatus, ChangeCandidate, ChangeDecision, RiskLevel
from ..utils.text import compact_preview


class ReviewAgent:
    def review(
        self,
        candidates: list[ChangeCandidate],
        interactive: bool = True,
        auto_confirm_low_risk: bool = False,
    ) -> list[ChangeDecision]:
        decisions: list[ChangeDecision] = []
        for index, candidate in enumerate(candidates, start=1):
            if auto_confirm_low_risk and candidate.risk_level == RiskLevel.LOW:
                candidate.status = CandidateStatus.CONFIRMED
                decisions.append(ChangeDecision(candidate.candidate_id, confirmed=True))
                continue

            if not interactive:
                decisions.append(ChangeDecision(candidate.candidate_id, confirmed=False, note="dry-run"))
                continue

            decisions.append(self._ask(index, len(candidates), candidate))
        return decisions

    def _ask(self, index: int, total: int, candidate: ChangeCandidate) -> ChangeDecision:
        self._print_candidate(index, total, candidate)
        while True:
            choice = input("操作 [Y确认/n跳过/e编辑/m更多/q退出] 默认 n: ").strip() or "n"
            if choice in {"Y", "y"}:
                candidate.status = CandidateStatus.CONFIRMED
                return ChangeDecision(candidate.candidate_id, confirmed=True)
            if choice == "n":
                candidate.status = CandidateStatus.SKIPPED
                return ChangeDecision(candidate.candidate_id, confirmed=False, note="skipped by reviewer")
            if choice == "e":
                replacement = input(f"新的替换文本 [{candidate.replacement_text}]: ").strip()
                if not replacement:
                    replacement = candidate.replacement_text
                candidate.replacement_text = replacement
                candidate.status = CandidateStatus.EDITED
                return ChangeDecision(candidate.candidate_id, confirmed=True, replacement_text=replacement)
            if choice == "m":
                self._print_more(candidate)
                continue
            if choice == "q":
                raise KeyboardInterrupt("review cancelled by user")
            print("无法识别的操作，请重新输入。")

    def _print_candidate(self, index: int, total: int, candidate: ChangeCandidate) -> None:
        print()
        print("=" * 80)
        print(f"[{index}/{total}] {candidate.file_path}")
        print(f"位置: {candidate.location_label}")
        print(f"风险: {candidate.risk_level.value} | 置信度: {candidate.confidence:.2f}")
        print("原因: " + "；".join(candidate.risk_reasons))
        if candidate.evidence_path:
            print(f"证据图/原文件: {candidate.evidence_path}")
        print("-" * 80)
        for line in candidate.context_before:
            print("  " + compact_preview(line))
        print(f"- {candidate.original_text}")
        print(f"+ {candidate.replacement_text}")
        for line in candidate.context_after:
            print("  " + compact_preview(line))

    def _print_more(self, candidate: ChangeCandidate) -> None:
        print()
        print("更多上下文:")
        for line in candidate.context_before:
            print("  " + line)
        print(f"> {candidate.original_text}")
        for line in candidate.context_after:
            print("  " + line)
