"""Backup helpers for safe execution."""

from __future__ import annotations

import shutil
import uuid
from datetime import datetime
from pathlib import Path


class BackupManager:
    def __init__(self, backup_root: Path | None = None):
        self.backup_root = backup_root or Path.cwd() / "out" / "backups"
        session = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:8]
        self.session_dir = self.backup_root / session
        self.session_dir.mkdir(parents=True, exist_ok=True)

    def create_backup(self, file_path: Path) -> Path:
        safe_name = file_path.name
        path_hash = uuid.uuid5(uuid.NAMESPACE_URL, str(file_path.resolve())).hex[:10]
        backup_path = self.session_dir / f"{path_hash}_{safe_name}"
        counter = 1
        while backup_path.exists():
            backup_path = self.session_dir / f"{path_hash}_{counter}_{safe_name}"
            counter += 1
        shutil.copy2(file_path, backup_path)
        return backup_path
