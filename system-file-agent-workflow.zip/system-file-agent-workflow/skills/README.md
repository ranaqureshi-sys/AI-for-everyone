# Agent Skills

这里的 `skills` 不是大模型平台里的插件，而是给本项目定义的 Agent 行为说明。后续如果接入真正的 LLM Agent、RPA 或工作流引擎，可以把这些说明变成提示词、系统规则或流程节点配置。

## Skill 列表

- [文件源发现 Skill](file-source-skill.md)
- [文档解析 Skill](parse-skill.md)
- [OCR 与手写风险 Skill](ocr-risk-skill.md)
- [人工审核 Skill](review-skill.md)
- [执行与审计 Skill](execute-audit-skill.md)
