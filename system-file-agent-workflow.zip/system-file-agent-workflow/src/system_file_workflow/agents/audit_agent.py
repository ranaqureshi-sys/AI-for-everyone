"""Audit and reporting agent."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from ..models import ChangeCandidate, ChangeRecord, WorkflowResult, to_jsonable
from ..utils.text import escape_markdown_cell


class AuditAgent:
    def __init__(self, output_dir: Path | None = None):
        self.output_dir = output_dir or Path.cwd() / "out"
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def write_candidates(self, candidates: list[ChangeCandidate], output_path: Path) -> Path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(to_jsonable(candidates), ensure_ascii=False, indent=2), encoding="utf-8")
        return output_path

    def write_report(
        self,
        task_id: str,
        candidates: list[ChangeCandidate],
        records: list[ChangeRecord],
    ) -> Path:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = self.output_dir / f"workflow_report_{task_id}_{timestamp}.md"
        json_path = self.output_dir / f"workflow_report_{task_id}_{timestamp}.json"

        json_data = {
            "task_id": task_id,
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "candidates": to_jsonable(candidates),
            "records": to_jsonable(records),
        }
        json_path.write_text(json.dumps(json_data, ensure_ascii=False, indent=2), encoding="utf-8")

        lines = [
            "# 体系文件批量修改任务报告",
            "",
            f"- 任务编号: `{task_id}`",
            f"- 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"- 候选项: {len(candidates)}",
            f"- 执行记录: {len(records)}",
            f"- 成功执行: {sum(1 for record in records if record.success)}",
            f"- 失败/需人工处理: {sum(1 for record in records if not record.success)}",
            f"- JSON 明细: `{json_path.name}`",
            "",
            "## 候选项清单",
            "",
            "| ID | 文件 | 位置 | 风险 | 原文 | 替换为 | 状态 |",
            "| --- | --- | --- | --- | --- | --- | --- |",
        ]

        for candidate in candidates:
            lines.append(
                "| "
                + " | ".join(
                    [
                        escape_markdown_cell(candidate.candidate_id),
                        escape_markdown_cell(str(candidate.file_path)),
                        escape_markdown_cell(candidate.location_label),
                        escape_markdown_cell(candidate.risk_level.value),
                        escape_markdown_cell(candidate.original_text),
                        escape_markdown_cell(candidate.replacement_text),
                        escape_markdown_cell(candidate.status.value),
                    ]
                )
                + " |"
            )

        lines.extend(
            [
                "",
                "## 执行记录",
                "",
                "| ID | 文件 | 位置 | 成功 | 备份 | 说明 |",
                "| --- | --- | --- | --- | --- | --- |",
            ]
        )

        for record in records:
            lines.append(
                "| "
                + " | ".join(
                    [
                        escape_markdown_cell(record.candidate_id),
                        escape_markdown_cell(str(record.file_path)),
                        escape_markdown_cell(record.location_label),
                        "是" if record.success else "否",
                        escape_markdown_cell(str(record.backup_path or "")),
                        escape_markdown_cell(record.message),
                    ]
                )
                + " |"
            )

        report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return report_path

    def summarize(
        self,
        task_id: str,
        total_files: int,
        total_chunks: int,
        candidates: list[ChangeCandidate],
        records: list[ChangeRecord],
        report_path: Path | None,
    ) -> WorkflowResult:
        return WorkflowResult(
            task_id=task_id,
            total_files=total_files,
            total_chunks=total_chunks,
            total_candidates=len(candidates),
            confirmed=sum(1 for item in candidates if item.status.value in {"confirmed", "edited", "executed"}),
            skipped=sum(1 for item in candidates if item.status.value == "skipped"),
            executed=sum(1 for record in records if record.success),
            failed=sum(1 for record in records if not record.success),
            report_path=report_path,
        )
