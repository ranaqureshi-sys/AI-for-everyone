"""Execution agent that applies confirmed changes."""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from ..models import CandidateStatus, ChangeCandidate, ChangeDecision, ChangeRecord
from ..utils.backup import BackupManager
from ..utils.office_zip import replace_in_office_zip
from ..utils.text import OFFICE_SUFFIXES, TEXT_SUFFIXES, read_text_with_fallback


class ExecuteAgent:
    def __init__(self, backup_manager: BackupManager | None = None):
        self.backup_manager = backup_manager or BackupManager()

    def execute(self, candidates: list[ChangeCandidate], decisions: list[ChangeDecision]) -> list[ChangeRecord]:
        decision_map = {decision.candidate_id: decision for decision in decisions if decision.confirmed}
        confirmed = [candidate for candidate in candidates if candidate.candidate_id in decision_map]
        for candidate in confirmed:
            decision = decision_map[candidate.candidate_id]
            if decision.replacement_text:
                candidate.replacement_text = decision.replacement_text

        records: list[ChangeRecord] = []
        grouped: dict[Path, list[ChangeCandidate]] = defaultdict(list)
        for candidate in confirmed:
            grouped[candidate.file_path].append(candidate)

        for file_path, file_candidates in grouped.items():
            suffix = file_path.suffix.lower()
            if suffix in TEXT_SUFFIXES:
                records.extend(self._execute_text_file(file_path, file_candidates))
            elif suffix == ".docx":
                records.extend(self._execute_office_file(file_path, file_candidates, ("word/",)))
            elif suffix == ".xlsx":
                records.extend(self._execute_office_file(file_path, file_candidates, ("xl/",)))
            else:
                for candidate in file_candidates:
                    candidate.status = CandidateStatus.MANUAL_REQUIRED
                    records.append(
                        ChangeRecord(
                            candidate_id=candidate.candidate_id,
                            file_path=file_path,
                            backup_path=None,
                            original_text=candidate.original_text,
                            replacement_text=candidate.replacement_text,
                            location_label=candidate.location_label,
                            success=False,
                            message=f"{suffix or 'unknown'} 暂不支持自动写回，需要人工处理",
                        )
                    )

        return records

    def _execute_text_file(self, file_path: Path, candidates: list[ChangeCandidate]) -> list[ChangeRecord]:
        backup_path = self.backup_manager.create_backup(file_path)
        content, encoding = read_text_with_fallback(file_path)
        records: list[ChangeRecord] = []

        pending = sorted(candidates, key=lambda item: item.absolute_start, reverse=True)
        for candidate in pending:
            start, end = candidate.absolute_start, candidate.absolute_end
            actual = content[start:end]
            if actual != candidate.original_text:
                candidate.status = CandidateStatus.FAILED
                records.append(
                    ChangeRecord(
                        candidate_id=candidate.candidate_id,
                        file_path=file_path,
                        backup_path=backup_path,
                        original_text=candidate.original_text,
                        replacement_text=candidate.replacement_text,
                        location_label=candidate.location_label,
                        success=False,
                        message=f"执行前校验失败，当前位置内容为: {actual!r}",
                    )
                )
                continue
            content = content[:start] + candidate.replacement_text + content[end:]
            candidate.status = CandidateStatus.EXECUTED
            records.append(
                ChangeRecord(
                    candidate_id=candidate.candidate_id,
                    file_path=file_path,
                    backup_path=backup_path,
                    original_text=candidate.original_text,
                    replacement_text=candidate.replacement_text,
                    location_label=candidate.location_label,
                    success=True,
                    message="modified",
                )
            )

        with file_path.open("w", encoding=encoding, newline="") as handle:
            handle.write(content)
        return records

    def _execute_office_file(
        self,
        file_path: Path,
        candidates: list[ChangeCandidate],
        entry_prefixes: tuple[str, ...],
    ) -> list[ChangeRecord]:
        backup_path = self.backup_manager.create_backup(file_path)
        replacements = [(candidate.original_text, candidate.replacement_text) for candidate in candidates]
        try:
            replaced = replace_in_office_zip(file_path, entry_prefixes, replacements)
        except Exception as exc:
            replaced = 0
            error = str(exc)
        else:
            error = ""

        records: list[ChangeRecord] = []
        for candidate in candidates:
            success = replaced > 0 and not error
            candidate.status = CandidateStatus.EXECUTED if success else CandidateStatus.FAILED
            records.append(
                ChangeRecord(
                    candidate_id=candidate.candidate_id,
                    file_path=file_path,
                    backup_path=backup_path,
                    original_text=candidate.original_text,
                    replacement_text=candidate.replacement_text,
                    location_label=candidate.location_label,
                    success=success,
                    message="modified by basic OOXML writer" if success else error or "未在 Office XML 中找到可写回文本",
                )
            )
        return records
